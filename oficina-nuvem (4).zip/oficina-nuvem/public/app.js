// ===== Oficina Admin — lógica do painel (modelo unificado) =====
const API = '';
const TOKEN_KEY = 'oficina_token';
const UID_KEY = 'oficina_uid';
let currentUser = null;
let token = null;
let DB = null;
function authHeaders(extra){ return Object.assign({'Authorization':'Bearer '+(token||'')}, extra||{}); }

// hash de senha (SHA-256 quando disponível; fallback simples)
async function sha256(str){
  try{
    if(window.crypto&&crypto.subtle){
      const buf=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(str));
      return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
    }
  }catch(e){}
  let h=0; for(let i=0;i<str.length;i++){h=(h*31+str.charCodeAt(i))>>>0;} return 'fb'+h.toString(16);
}

function normalize(d){
  if(!d || typeof d!=='object') d = {};
  if(!Array.isArray(d.clientes)) d.clientes = [];
  if(!Array.isArray(d.ordens)) d.ordens = [];
  if(!Array.isArray(d.agenda)) d.agenda = [];
  if(!Array.isArray(d.estoque)) d.estoque = [];
  if(!Array.isArray(d.financeiro)) d.financeiro = [];
  if(!d.config) d.config = { nomeSite: 'Oficina', subtitulo: 'Painel Admin' };
  if(!Array.isArray(d.config.pagamentos)) d.config.pagamentos = ['Dinheiro','PIX','Cartão de crédito','Cartão de débito','Boleto','Transferência'];
  if(!Array.isArray(d.config.categorias)) d.config.categorias = ['Lubrificantes','Filtros','Freios','Motor','Elétrica','Suspensão'];
  if(typeof d.config.cor!=='string') d.config.cor = '#2563eb';
  if(typeof d.config.telefone!=='string') d.config.telefone = '';
  if(typeof d.config.endereco!=='string') d.config.endereco = '';
  if(typeof d.config.cnpj!=='string') d.config.cnpj = '';
  if(typeof d.config.email!=='string') d.config.email = '';
  if(typeof d.config.abertura!=='string') d.config.abertura = '08:00';
  if(typeof d.config.fechamento!=='string') d.config.fechamento = '18:00';
  if(typeof d.config.dias!=='string') d.config.dias = 'Segunda a sexta';
  if(typeof d.config.horaAbertura!=='string') d.config.horaAbertura = '08:00';
  if(typeof d.config.horaFechamento!=='string') d.config.horaFechamento = '18:00';
  if(typeof d.config.diasFuncionamento!=='string') d.config.diasFuncionamento = 'Segunda a Sexta';
  if(!d.config.a11yUI) d.config.a11yUI = {escala:true,escuro:true,contraste:true,animacoes:true,teclado:true,botao:'topbar'};
  if(!d.config.permissoes) d.config.permissoes = {'Atendente':['dashboard','clientes','ordens','agenda','estoque'],'Mecânico':['dashboard','ordens','agenda']};
  if(!Array.isArray(d.config.categorias)) d.config.categorias = ['Lubrificantes','Filtros','Freios','Motor','Elétrica','Suspensão','Pneus'];
  if(!d.config.contato) d.config.contato = { endereco:'', telefone:'', cnpj:'' };
  if(!d.config.cor) d.config.cor = '#2563eb';
  if(!Array.isArray(d.usuarios)||!d.usuarios.length) d.usuarios = [{id:1,nome:'Administrador',perfil:'Administrador',login:'admin',senhaHash:'240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9'}];
  if(!Array.isArray(d.mecanicos)) d.mecanicos = [];
  return d;
}
function applyBrand(){
  const el=document.querySelector('.brand-text');
  if(el) el.innerHTML='<strong>'+esc(DB.config.nomeSite||'Oficina')+'</strong><span>'+esc(DB.config.subtitulo||'Painel Admin')+'</span>';
}
function shade(hex,pct){
  try{const n=parseInt(hex.slice(1),16);let r=(n>>16)&255,g=(n>>8)&255,b=n&255;r=Math.max(0,Math.min(255,Math.round(r*(1-pct))));g=Math.max(0,Math.min(255,Math.round(g*(1-pct))));b=Math.max(0,Math.min(255,Math.round(b*(1-pct))));return '#'+((1<<24)+(r<<16)+(g<<8)+b).toString(16).slice(1);}catch(e){return hex;}
}
function applyTheme(){
  const cor=DB.config.cor||'#2563eb';
  document.documentElement.style.setProperty('--brand',cor);
  document.documentElement.style.setProperty('--brand-d',shade(cor,0.18));
}
let _saving=false,_saveAgain=false;
async function save(){
  if(!DB||!token) return;
  if(_saving){ _saveAgain=true; return; }
  _saving=true;
  try{
    const r=await fetch(API+'/api/data',{method:'PUT',headers:authHeaders({'Content-Type':'application/json'}),body:JSON.stringify(DB)});
    if(!r.ok) throw new Error('http '+r.status);
  }catch(e){ toast('Sem conexão — mudança não salva no servidor'); }
  _saving=false;
  if(_saveAgain){ _saveAgain=false; save(); }
}
async function fetchDB(){
  const r=await fetch(API+'/api/data',{headers:authHeaders()});
  if(r.status===401){ return null; }
  if(!r.ok) throw new Error('http '+r.status);
  return normalize(await r.json());
}

// ===== ACESSIBILIDADE =====
const A11Y_KEY='oficina_a11y';
const A11Y_STEPS=[90,100,110,125,150];
let a11y={escala:100,contraste:false,animacoes:false,teclado:false,escuro:false};
function loadA11y(){
  try{const raw=localStorage.getItem(A11Y_KEY);if(raw)a11y=Object.assign(a11y,JSON.parse(raw));}catch(e){}
}
function saveA11y(){ try{localStorage.setItem(A11Y_KEY,JSON.stringify(a11y));}catch(e){} }
function applyA11y(){
  document.body.style.zoom=(a11y.escala/100);
  document.body.classList.toggle('hc',!!a11y.contraste);
  document.body.classList.toggle('dark',!!a11y.escuro);
  document.body.classList.toggle('reduce-motion',!!a11y.animacoes);
  document.body.classList.toggle('kbd-focus',!!a11y.teclado);
  const lbl=document.getElementById('a11ySizeLbl');if(lbl)lbl.textContent=a11y.escala+'%';
  const c=document.getElementById('a11yContrast');if(c)c.checked=!!a11y.contraste;
  const dk0=document.getElementById('a11yDark');if(dk0)dk0.checked=!!a11y.escuro;
  const m=document.getElementById('a11yMotion');if(m)m.checked=!!a11y.animacoes;
  const f=document.getElementById('a11yFocus');if(f)f.checked=!!a11y.teclado;
  applyA11yUI();
}
function applyA11yUI(){
  const u=(DB&&DB.config&&DB.config.a11yUI)||{escala:true,escuro:true,contraste:true,animacoes:true,teclado:true,botao:'topbar'};
  const setRow=(id,on)=>{const el=document.getElementById(id);if(el)el.hidden=!on;};
  setRow('rowEscala',u.escala);
  setRow('rowDark',u.escuro);
  setRow('rowContraste',u.contraste);
  setRow('rowMotion',u.animacoes);
  setRow('rowFocus',u.teclado);
  const btn=document.getElementById('btnA11y');
  const panel=document.getElementById('a11yPanel');
  if(btn){
    btn.classList.remove('floating','pos-br','pos-bl','pos-tr');
    if(u.botao&&u.botao!=='topbar'){
      btn.classList.add('floating');
      btn.classList.add(u.botao==='inferior-esquerdo'?'pos-bl':u.botao==='superior-direito'?'pos-tr':'pos-br');
    }
  }
  if(panel){
    panel.classList.remove('pos-br','pos-bl','pos-tr');
    if(u.botao==='inferior-direito')panel.classList.add('pos-br');
    else if(u.botao==='inferior-esquerdo')panel.classList.add('pos-bl');
    else if(u.botao==='superior-direito')panel.classList.add('pos-tr');
  }
}
function changeEscala(dir){
  const i=A11Y_STEPS.indexOf(a11y.escala);
  let ni=(i<0?1:i)+dir;
  ni=Math.max(0,Math.min(A11Y_STEPS.length-1,ni));
  a11y.escala=A11Y_STEPS[ni];saveA11y();applyA11y();
}
function bindA11y(){
  const panel=document.getElementById('a11yPanel');
  const btn=document.getElementById('btnA11y');
  if(!panel||!btn)return;
  const openP=()=>{panel.hidden=false;btn.setAttribute('aria-expanded','true');};
  const closeP=()=>{panel.hidden=true;btn.setAttribute('aria-expanded','false');};
  btn.addEventListener('click',()=>{panel.hidden?openP():closeP();});
  const cl=document.getElementById('a11yClose');if(cl)cl.addEventListener('click',closeP);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!panel.hidden)closeP();});
  document.addEventListener('click',e=>{if(!panel.hidden&&!panel.contains(e.target)&&e.target!==btn)closeP();});
  const plus=document.getElementById('a11yPlus');if(plus)plus.addEventListener('click',()=>changeEscala(1));
  const minus=document.getElementById('a11yMinus');if(minus)minus.addEventListener('click',()=>changeEscala(-1));
  const c=document.getElementById('a11yContrast');if(c)c.addEventListener('change',()=>{a11y.contraste=c.checked;saveA11y();applyA11y();});
  const m=document.getElementById('a11yMotion');if(m)m.addEventListener('change',()=>{a11y.animacoes=m.checked;saveA11y();applyA11y();});
  const f=document.getElementById('a11yFocus');if(f)f.addEventListener('change',()=>{a11y.teclado=f.checked;saveA11y();applyA11y();});
  const rs=document.getElementById('a11yReset');if(rs)rs.addEventListener('click',()=>{a11y={escala:100,contraste:false,animacoes:false,teclado:false};saveA11y();applyA11y();toast('Acessibilidade restaurada');});
}
function nextId(arr){ return arr.length ? Math.max(...arr.map(x=>x.id))+1 : 1; }

// ---- helpers ----
function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function brl(n){ return (Number(n)||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'}); }
function dt(s){ if(!s) return '-'; const p=s.split('-'); return p.length===3?`${p[2]}/${p[1]}/${p[0]}`:s; }
function cli(id){ return DB.clientes.find(x=>x.id===id); }
function clienteNome(id){ const c=cli(id); return c?c.nome:'—'; }
function clienteLabel(id){ const c=cli(id); return c?`${c.nome} · ${c.marca} ${c.modelo}${c.placa?' · '+c.placa:''}` : '—'; }

const PAGAMENTOS = ['Não definido','Dinheiro','PIX','Cartão de crédito','Cartão de débito','Boleto','Transferência'];
function getPagamentos(){ return ['Não definido'].concat(DB.config.pagamentos||[]); }
const PERFIS = ['Administrador','Atendente','Mecânico'];
const PERMISSOES = {
  'Administrador':['dashboard','clientes','ordens','agenda','estoque','financeiro','config'],
  'Atendente':['dashboard','clientes','ordens','agenda','estoque'],
  'Mecânico':['dashboard','ordens','agenda']
};
function isAdmin(){ return currentUser && currentUser.perfil==='Administrador'; }
function permsDe(perfil){
  if(perfil==='Administrador') return PERMISSOES['Administrador'];
  const cfg=DB.config&&DB.config.permissoes;
  if(cfg&&Array.isArray(cfg[perfil])) return cfg[perfil].concat(perfil==='Administrador'?['config']:[]);
  return PERMISSOES[perfil]||PERMISSOES['Administrador'];
}
function allowed(view){ const p=permsDe(currentUser?currentUser.perfil:'Administrador'); return p.includes(view); }
function applyPermissions(){ document.querySelectorAll('.menu-item').forEach(b=>{ b.hidden=!allowed(b.dataset.view); }); const rst=document.getElementById('btnReset'); if(rst) rst.hidden=!isAdmin(); }
const STATUS = {
  aguardando:{t:'Aguardando',c:'b-amber'},
  em_andamento:{t:'Em andamento',c:'b-blue'},
  concluida:{t:'Concluída',c:'b-green'},
  cancelada:{t:'Cancelada',c:'b-gray'}
};

function toast(msg){
  const el=document.getElementById('toast');
  el.textContent=msg; el.hidden=false;
  clearTimeout(el._t); el._t=setTimeout(()=>el.hidden=true,2200);
}

// botões de ação (editar / excluir) com rótulo
function acoes(tipo,id){
  return `<div class="tbl-actions"><button class="btn-edit" data-edit="${tipo}" data-id="${id}">✏️ Editar</button><button class="icon-btn danger" data-del="${tipo}" data-id="${id}" title="Excluir">🗑️</button></div>`;
}

// ---- navegação ----
let current='dashboard';
let searchTerm='';
const TITLES={dashboard:'Dashboard',clientes:'Clientes e Veículos',ordens:'Ordens de Serviço',agenda:'Agenda',estoque:'Estoque',financeiro:'Financeiro',config:'Configurações'};

function navigate(view){
  if(!allowed(view)){ const p=permsDe(currentUser?currentUser.perfil:'Administrador'); view=p[0]||'dashboard'; }
  current=view; searchTerm='';
  document.getElementById('globalSearch').value='';
  document.querySelectorAll('.menu-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
  document.getElementById('viewTitle').textContent=TITLES[view];
  document.getElementById('sidebar').classList.remove('open');
  render();
}

function render(){
  const c=document.getElementById('content');
  const map={dashboard:viewDashboard,clientes:viewClientes,ordens:viewOrdens,agenda:viewAgenda,estoque:viewEstoque,financeiro:viewFinanceiro,config:viewConfig};
  c.innerHTML=(map[current]||viewDashboard)();
  bindViewEvents();
}

function filtro(list, campos){
  if(!searchTerm) return list;
  const q=searchTerm.toLowerCase();
  return list.filter(o=>campos.some(f=>String(o[f]!=null?o[f]:'').toLowerCase().includes(q)));
}
// ===== DASHBOARD =====
function viewDashboard(){
  const abertas=DB.ordens.filter(o=>o.status!=='concluida'&&o.status!=='cancelada');
  const receber=DB.ordens.filter(o=>!o.pago).reduce((s,o)=>s+o.valor,0);
  const faturado=DB.ordens.filter(o=>o.pago).reduce((s,o)=>s+o.valor,0);
  const baixo=DB.estoque.filter(p=>p.qtd<=p.minimo);
  const stat=(lbl,val,sub,ic,bg,color)=>`<div class="stat"><div class="lbl"><span class="ic" style="background:${bg};color:${color}">${ic}</span>${lbl}</div><div class="val">${val}</div><div class="sub">${sub}</div></div>`;
  const recentes=[...DB.ordens].sort((a,b)=>b.entrada.localeCompare(a.entrada)).slice(0,5);
  const hoje=DB.agenda.filter(a=>a.data==='2025-09-24');
  const cfg=DB.config;
  const horario=(cfg.abertura&&cfg.fechamento)?`<div class="panel" style="margin-bottom:16px;display:flex;align-items:center;gap:12px;flex-wrap:wrap"><span style="font-size:22px">🕐</span><div><strong>Horário de funcionamento:</strong> ${esc(cfg.abertura)} às ${esc(cfg.fechamento)}${cfg.dias?` · ${esc(cfg.dias)}`:''}</div></div>`:'';
  return `
  ${horario}
  <div class="stats">
    ${stat('Ordens abertas',abertas.length,'serviços em aberto','🔧','#dbeafe','#1d4ed8')}
    ${stat('A receber',brl(receber),'pagamentos pendentes','⏳','#fef3c7','#b45309')}
    ${stat('Faturado',brl(faturado),'ordens quitadas','💰','#dcfce7','#15803d')}
    ${stat('Estoque baixo',baixo.length,'itens abaixo do mínimo','📦','#fee2e2','#b91c1c')}
  </div>
  <div class="grid-2">
    <div class="panel">
      <h2>Ordens recentes <button class="btn-ghost" data-goto="ordens">Ver todas</button></h2>
      <div class="tbl-wrap"><table><thead><tr><th>OS</th><th>Cliente / Veículo</th><th>Serviço</th><th>Status</th><th>Valor</th></tr></thead><tbody>
      ${recentes.map(o=>`<tr><td>#${o.id}</td><td>${esc(clienteLabel(o.clienteId))}</td><td>${esc(o.descricao)}</td><td><span class="badge ${STATUS[o.status].c}">${STATUS[o.status].t}</span></td><td>${brl(o.valor)}</td></tr>`).join('')}
      </tbody></table></div>
    </div>
    <div class="panel">
      <h2>Agenda de hoje</h2>
      <div class="agenda-list">
      ${hoje.length?hoje.map(a=>`<div class="agenda-card"><div class="agenda-time"><strong>${a.hora}</strong><span>hoje</span></div><div class="agenda-info"><strong>${esc(a.servico)}</strong><p>${esc(clienteLabel(a.clienteId))} · ${esc(a.mecanico)}</p></div></div>`).join(''):'<div class="empty">Sem agendamentos hoje</div>'}
      </div>
    </div>
  </div>`;
}

// ===== CLIENTES + VEÍCULOS (unificado) =====
function viewClientes(){
  const list=filtro(DB.clientes,['nome','telefone','marca','modelo','placa']);
  return `
  <div class="toolbar"><div class="grow"></div><button class="btn-primary" data-add="cliente">+ Novo cliente</button></div>
  <div class="panel"><div class="tbl-wrap"><table><thead><tr><th>Cliente</th><th>Telefone</th><th>Veículo</th><th>Placa</th><th>Ordens</th><th>Ações</th></tr></thead><tbody>
  ${list.length?list.map(c=>`<tr><td><strong>${esc(c.nome)}</strong></td><td>${esc(c.telefone)}</td><td>${esc(c.marca)} ${esc(c.modelo)}</td><td>${esc(c.placa)||'—'}</td><td>${DB.ordens.filter(o=>o.clienteId===c.id).length}</td><td>${acoes('cliente',c.id)}</td></tr>`).join(''):'<tr><td colspan="6" class="empty">Nenhum cliente encontrado</td></tr>'}
  </tbody></table></div></div>`;
}
// ===== ORDENS DE SERVIÇO =====
function viewOrdens(){
  const list=filtro(DB.ordens,['descricao','mecanico']).sort((a,b)=>b.id-a.id);
  return `
  <div class="toolbar"><div class="grow"></div><button class="btn-primary" data-add="ordem">+ Nova OS</button></div>
  <div class="panel"><div class="tbl-wrap"><table><thead><tr><th>OS</th><th>Cliente / Veículo</th><th>Serviço</th><th>Mecânico</th><th>Entrada</th><th>Status</th><th>Valor</th><th>Pago</th><th>Forma</th><th>Ações</th></tr></thead><tbody>
  ${list.length?list.map(o=>`<tr><td><strong>#${o.id}</strong></td><td>${esc(clienteLabel(o.clienteId))}</td><td>${esc(o.descricao)}</td><td>${esc(o.mecanico)}</td><td>${dt(o.entrada)}</td><td><span class="badge ${STATUS[o.status].c}">${STATUS[o.status].t}</span></td><td>${brl(o.valor)}</td><td><span class="badge ${o.pago?'b-green':'b-red'}">${o.pago?'Sim':'Não'}</span></td><td>${esc(o.formaPagamento||'—')}</td><td>${acoes('ordem',o.id)}</td></tr>`).join(''):'<tr><td colspan="10" class="empty">Nenhuma ordem encontrada</td></tr>'}
  </tbody></table></div></div>`;
}

// ===== AGENDA =====
function viewAgenda(){
  const list=filtro(DB.agenda,['servico','mecanico']).sort((a,b)=>(a.data+a.hora).localeCompare(b.data+b.hora));
  const grupos={};
  list.forEach(a=>{(grupos[a.data]=grupos[a.data]||[]).push(a);});
  const dias=Object.keys(grupos).sort();
  return `
  <div class="toolbar"><div class="grow"></div><button class="btn-primary" data-add="agendamento">+ Novo agendamento</button></div>
  ${dias.length?dias.map(d=>`<div class="panel" style="margin-bottom:16px"><h2>${dt(d)}</h2><div class="agenda-list">
    ${grupos[d].map(a=>`<div class="agenda-card"><div class="agenda-time"><strong>${a.hora}</strong><span>${esc(a.mecanico.split(' ')[0])}</span></div><div class="agenda-info"><strong>${esc(a.servico)}</strong><p>${esc(clienteLabel(a.clienteId))}</p></div><div class="tbl-actions"><button class="btn-edit" data-edit="agendamento" data-id="${a.id}">✏️ Editar</button><button class="icon-btn danger" data-del="agendamento" data-id="${a.id}">🗑️</button></div></div>`).join('')}
  </div></div>`).join(''):'<div class="panel"><div class="empty">Nenhum agendamento</div></div>'}`;
}

// ===== ESTOQUE =====
function viewEstoque(){
  const list=filtro(DB.estoque,['nome','categoria']);
  return `
  <div class="toolbar"><div class="grow"></div><button class="btn-primary" data-add="peca">+ Nova peça</button></div>
  <div class="panel"><div class="tbl-wrap"><table><thead><tr><th>Peça</th><th>Categoria</th><th>Condição</th><th>Qtd.</th><th>Mínimo</th><th>Preço</th><th>Situação</th><th>Ações</th></tr></thead><tbody>
  ${list.length?list.map(p=>{const baixo=p.qtd<=p.minimo;const cond=p.condicao||'Nova';const cc=cond==='Usada'?'b-red':cond==='Seminova'?'b-amber':'b-blue';return `<tr><td><div style="display:flex;align-items:center;gap:10px"><div style="width:40px;height:40px;border-radius:8px;overflow:hidden;background:#eef2f7;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0">${p.foto?`<img src="${p.foto}" style="width:100%;height:100%;object-fit:cover">`:'🔩'}</div><strong>${esc(p.nome)}</strong></div></td><td>${esc(p.categoria)}</td><td><span class="badge ${cc}">${esc(cond)}</span></td><td>${p.qtd}</td><td>${p.minimo}</td><td>${brl(p.preco)}</td><td><span class="badge ${baixo?'b-red':'b-green'}">${baixo?'Repor':'OK'}</span></td><td>${acoes('peca',p.id)}</td></tr>`;}).join(''):'<tr><td colspan="8" class="empty">Nenhuma peça encontrada</td></tr>'}
  </tbody></table></div></div>`;
}

// ===== FINANCEIRO =====
function viewFinanceiro(){
  const pagas=DB.ordens.filter(o=>o.pago);
  const pend=DB.ordens.filter(o=>!o.pago);
  const receita=pagas.reduce((s,o)=>s+o.valor,0);
  const areceber=pend.reduce((s,o)=>s+o.valor,0);
  const estoqueVal=DB.estoque.reduce((s,p)=>s+p.qtd*p.preco,0);
  const stat=(lbl,val,ic,bg,color)=>`<div class="stat"><div class="lbl"><span class="ic" style="background:${bg};color:${color}">${ic}</span>${lbl}</div><div class="val">${val}</div></div>`;
  const max=Math.max(receita,areceber,estoqueVal,1);
  const barra=(lbl,v,cor)=>`<div style="margin-bottom:14px"><div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:6px"><span>${lbl}</span><strong>${brl(v)}</strong></div><div class="bar"><span style="width:${(v/max*100).toFixed(0)}%;background:${cor}"></span></div></div>`;
  return `
  <div class="stats">
    ${stat('Receita recebida',brl(receita),'💰','#dcfce7','#15803d')}
    ${stat('A receber',brl(areceber),'⏳','#fef3c7','#b45309')}
    ${stat('Valor em estoque',brl(estoqueVal),'📦','#ede9fe','#6d28d9')}
  </div>
  <div class="grid-2">
    <div class="panel"><h2>Comparativo</h2>${barra('Receita recebida',receita,'#16a34a')}${barra('A receber',areceber,'#d97706')}${barra('Valor em estoque',estoqueVal,'#7c3aed')}</div>
    <div class="panel"><h2>Pagamentos pendentes</h2><div class="tbl-wrap"><table><thead><tr><th>OS</th><th>Cliente</th><th>Valor</th></tr></thead><tbody>
    ${pend.length?pend.map(o=>`<tr><td>#${o.id}</td><td>${esc(clienteNome(o.clienteId))}</td><td>${brl(o.valor)}</td></tr>`).join(''):'<tr><td colspan="3" class="empty">Tudo quitado 🎉</td></tr>'}
    </tbody></table></div></div>
  </div>
  <div class="panel" style="margin-top:16px"><h2>Recebimentos por forma de pagamento</h2><div class="tbl-wrap"><table><thead><tr><th>Forma de pagamento</th><th>Qtd. de OS</th><th>Total recebido</th></tr></thead><tbody>
    ${(function(){const g={};pagas.forEach(o=>{const f=o.formaPagamento||'Não definido';g[f]=g[f]||{n:0,v:0};g[f].n++;g[f].v+=o.valor;});const ks=Object.keys(g);return ks.length?ks.sort((a,b)=>g[b].v-g[a].v).map(k=>`<tr><td>${esc(k)}</td><td>${g[k].n}</td><td>${brl(g[k].v)}</td></tr>`).join(''):'<tr><td colspan="3" class="empty">Nenhum recebimento registrado</td></tr>';})()}
    </tbody></table></div></div>`;
}
// ===== CONFIGURAÇÕES =====
function viewConfig(){
  const mecs=DB.mecanicos;
  const cfg=DB.config;
  const foto=currentUser&&currentUser.foto?currentUser.foto:'';
  const cor=cfg.cor||'#2563eb';
  return `
  <div class="panel" style="margin-bottom:16px">
    <h2>Meu perfil</h2>
    <div style="display:flex;gap:20px;align-items:center;flex-wrap:wrap">
      <div style="width:96px;height:96px;border-radius:50%;overflow:hidden;background:${cor};display:flex;align-items:center;justify-content:center;color:#fff;font-size:34px;font-weight:700;flex-shrink:0" id="perfilPreview">${foto?`<img src="${foto}" style="width:100%;height:100%;object-fit:cover">`:esc((currentUser?currentUser.nome:'?').charAt(0).toUpperCase())}</div>
      <div style="flex:1;min-width:220px">
        <form id="formPerfil">
          <div style="margin-bottom:12px"><label>Seu nome</label><input name="nome" value="${esc(currentUser?currentUser.nome:'')}" required></div>
          <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
            <label class="btn-edit" style="cursor:pointer">📷 Trocar foto<input type="file" id="fotoInput" accept="image/*" hidden></label>
            ${foto?'<button type="button" class="icon-btn danger" id="rmFoto" title="Remover foto">🗑️ Remover foto</button>':''}
            <button type="submit" class="btn-primary">Salvar perfil</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <div class="grid-2">
    <div class="panel">
      <h2>Dados do site</h2>
      <form id="formSite">
        <div style="margin-bottom:12px"><label>Nome da oficina</label><input name="nomeSite" value="${esc(cfg.nomeSite)}" required></div>
        <div style="margin-bottom:12px"><label>Subtítulo (aparece embaixo do nome)</label><input name="subtitulo" value="${esc(cfg.subtitulo)}"></div>
        <div style="margin-bottom:12px"><label>Telefone da oficina</label><input name="telefone" value="${esc(cfg.telefone||'')}"></div>
        <div style="margin-bottom:12px"><label>Endereço</label><input name="endereco" value="${esc(cfg.endereco||'')}"></div>
        <div style="margin-bottom:12px"><label>CNPJ</label><input name="cnpj" value="${esc(cfg.cnpj||'')}"></div>
        <div style="margin-bottom:12px"><label>E-mail da empresa</label><input name="email" type="email" value="${esc(cfg.email||'')}" placeholder="contato@suaoficina.com.br"></div>
        <div style="display:flex;gap:12px;margin-bottom:12px">
          <div style="flex:1"><label>Horário de abertura</label><input name="abertura" type="time" value="${esc(cfg.abertura||'08:00')}"></div>
          <div style="flex:1"><label>Horário de fechamento</label><input name="fechamento" type="time" value="${esc(cfg.fechamento||'18:00')}"></div>
        </div>
        <div style="margin-bottom:12px"><label>Dias de funcionamento</label><input name="dias" value="${esc(cfg.dias||'')}" placeholder="Ex.: Segunda a sexta, sábado até 12h"></div>
        <div style="margin-bottom:12px"><label>Cor principal do painel</label><input name="cor" type="color" value="${cor}" style="width:70px;height:40px;padding:2px"></div>
        <button type="submit" class="btn-primary">Salvar dados do site</button>
      </form>
    </div>
    <div class="panel">
      <h2>Mecânicos</h2>
      <form id="formMec" style="display:flex;gap:8px;margin-bottom:14px">
        <input name="nome" placeholder="Nome do mecânico" required style="flex:1">
        <button type="submit" class="btn-primary">+ Adicionar</button>
      </form>
      <div class="tbl-wrap"><table><thead><tr><th>Nome</th><th>Ordens</th><th></th></tr></thead><tbody>
      ${mecs.length?mecs.map(m=>`<tr><td>${esc(m)}</td><td>${DB.ordens.filter(o=>o.mecanico===m).length}</td><td><button class="icon-btn danger" data-rmmec="${esc(m)}" title="Remover">🗑️</button></td></tr>`).join(''):'<tr><td colspan="3" class="empty">Nenhum mecânico cadastrado</td></tr>'}
      </tbody></table></div>
    </div>
  </div>
  <div class="grid-2" style="margin-top:16px">
    <div class="panel">
      <h2>Formas de pagamento</h2>
      <form id="formPag" style="display:flex;gap:8px;margin-bottom:14px">
        <input name="nome" placeholder="Ex.: Vale, Cheque..." required style="flex:1">
        <button type="submit" class="btn-primary">+ Adicionar</button>
      </form>
      <div class="tbl-wrap"><table><thead><tr><th>Forma</th><th></th></tr></thead><tbody>
      ${DB.config.pagamentos.length?DB.config.pagamentos.map(p=>`<tr><td>${esc(p)}</td><td><button class="icon-btn danger" data-rmpag="${esc(p)}" title="Remover">🗑️</button></td></tr>`).join(''):'<tr><td colspan="2" class="empty">Nenhuma forma cadastrada</td></tr>'}
      </tbody></table></div>
    </div>
    <div class="panel">
      <h2>Usuários e acessos</h2>
      <form id="formUser" style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px">
        <input name="nome" placeholder="Nome" required>
        <input name="login" placeholder="Usuário (login)" required>
        <input name="senha" type="password" placeholder="Senha" required>
        <select name="perfil">${PERFIS.map(p=>`<option value="${esc(p)}">${esc(p)}</option>`).join('')}</select>
        <button type="submit" class="btn-primary" style="grid-column:1/-1">+ Adicionar usuário</button>
      </form>
      <div class="tbl-wrap"><table><thead><tr><th>Nome</th><th>Login</th><th>Perfil</th><th></th></tr></thead><tbody>
      ${DB.usuarios.length?DB.usuarios.map(u=>`<tr><td>${esc(u.nome)}</td><td>${esc(u.login||'—')}</td><td><span class="badge ${u.perfil==='Administrador'?'b-violet':u.perfil==='Atendente'?'b-blue':'b-gray'}">${esc(u.perfil)}</span></td><td><div class="tbl-actions"><button class="btn-edit" data-pwuser="${u.id}">🔑 Senha</button><button class="icon-btn danger" data-rmuser="${u.id}" title="Remover">🗑️</button></div></td></tr>`).join(''):'<tr><td colspan="4" class="empty">Nenhum usuário cadastrado</td></tr>'}
      </tbody></table></div>
      <p style="font-size:12px;color:var(--muted);margin-top:10px">O acesso ao painel exige login e senha. As senhas são guardadas com criptografia (hash SHA-256) no próprio navegador.</p>
    </div>
  </div>
  <div class="panel" style="margin-top:16px">
    <h2>Categorias de peças</h2>
    <form id="formCat" style="display:flex;gap:8px;margin-bottom:14px">
      <input name="nome" placeholder="Ex.: Freios, Óleo, Filtros..." required style="flex:1">
      <button type="submit" class="btn-primary">+ Adicionar</button>
    </form>
    <div style="display:flex;flex-wrap:wrap;gap:8px">
      ${(cfg.categorias&&cfg.categorias.length)?cfg.categorias.map(c=>`<span class="badge b-gray" style="display:inline-flex;align-items:center;gap:6px;padding:6px 10px">${esc(c)}<button class="icon-btn danger" data-rmcat="${esc(c)}" title="Remover" style="padding:0 2px">×</button></span>`).join(''):'<span class="empty">Nenhuma categoria cadastrada</span>'}
    </div>
  </div>
  <div class="panel" style="margin-top:16px">
    <h2>♿ Opções de acessibilidade (administrador)</h2>
    <p style="font-size:13px;color:var(--muted);margin-bottom:14px">Escolha quais opções aparecem no menu de acessibilidade (botão ♿) e onde o botão fica.</p>
    <form id="formA11yUI">
      <div style="display:flex;flex-wrap:wrap;gap:14px;margin-bottom:16px">
        <label style="display:flex;align-items:center;gap:6px;font-weight:500"><input type="checkbox" name="escala" ${cfg.a11yUI.escala?'checked':''}> Tamanho do texto</label>
        <label style="display:flex;align-items:center;gap:6px;font-weight:500"><input type="checkbox" name="escuro" ${cfg.a11yUI.escuro?'checked':''}> Modo escuro</label>
        <label style="display:flex;align-items:center;gap:6px;font-weight:500"><input type="checkbox" name="contraste" ${cfg.a11yUI.contraste?'checked':''}> Alto contraste</label>
        <label style="display:flex;align-items:center;gap:6px;font-weight:500"><input type="checkbox" name="animacoes" ${cfg.a11yUI.animacoes?'checked':''}> Reduzir animações</label>
        <label style="display:flex;align-items:center;gap:6px;font-weight:500"><input type="checkbox" name="teclado" ${cfg.a11yUI.teclado?'checked':''}> Destaque de teclado</label>
      </div>
      <div style="margin-bottom:14px;max-width:320px"><label>Posição do botão ♿</label><select name="botao">
        <option value="topbar" ${cfg.a11yUI.botao==='topbar'?'selected':''}>No topo (padrão)</option>
        <option value="inferior-direito" ${cfg.a11yUI.botao==='inferior-direito'?'selected':''}>Flutuante — canto inferior direito</option>
        <option value="inferior-esquerdo" ${cfg.a11yUI.botao==='inferior-esquerdo'?'selected':''}>Flutuante — canto inferior esquerdo</option>
        <option value="superior-direito" ${cfg.a11yUI.botao==='superior-direito'?'selected':''}>Flutuante — canto superior direito</option>
      </select></div>
      <button type="submit" class="btn-primary">Salvar opções de acessibilidade</button>
    </form>
  </div>
  <div class="panel" style="margin-top:16px">
    <h2>🔐 Controle de acessos por perfil</h2>
    <p style="font-size:13px;color:var(--muted);margin-bottom:14px">Escolha o que cada tipo de usuário pode abrir. O Administrador sempre tem acesso a tudo, inclusive às Configurações.</p>
    <form id="formPerms">
      <div class="tbl-wrap"><table><thead><tr><th>Área</th><th style="text-align:center">Atendente</th><th style="text-align:center">Mecânico</th></tr></thead><tbody>
      ${(function(){const secs=[['dashboard','Dashboard'],['clientes','Clientes / Veículos'],['ordens','Ordens de Serviço'],['agenda','Agenda'],['estoque','Estoque'],['financeiro','Financeiro']];const pm=cfg.permissoes||{};const at=pm['Atendente']||[];const me=pm['Mecânico']||[];return secs.map(s=>`<tr><td>${esc(s[1])}</td><td style="text-align:center"><input type="checkbox" name="Atendente" value="${s[0]}" ${at.includes(s[0])?'checked':''} style="width:20px;height:20px"></td><td style="text-align:center"><input type="checkbox" name="Mecânico" value="${s[0]}" ${me.includes(s[0])?'checked':''} style="width:20px;height:20px"></td></tr>`).join('');})()}
      </tbody></table></div>
      <button type="submit" class="btn-primary" style="margin-top:14px">Salvar acessos por perfil</button>
    </form>
  </div>
  <div class="panel" style="margin-top:16px">
    <h2>🔒 Área do administrador</h2>
    <p style="font-size:13px;color:var(--muted);margin-bottom:14px">Ferramentas exclusivas do administrador para proteger e transferir os dados da oficina.</p>
    <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:center">
      <button type="button" class="btn-primary" id="btnBackup">💾 Baixar cópia de segurança</button>
      <label class="btn-edit" style="cursor:pointer">📂 Restaurar de um arquivo<input type="file" id="importInput" accept="application/json,.json" hidden></label>
    </div>
    <p style="font-size:12px;color:var(--muted);margin-top:10px">A cópia de segurança guarda clientes, ordens, estoque, usuários e configurações em um arquivo. Restaurar substitui todos os dados atuais.</p>
  </div>`;
}

// ===== FORMULÁRIOS / MODAL =====
function cliOpts(val){ return DB.clientes.map(c=>`<option value="${c.id}" ${c.id===val?'selected':''}>${esc(c.nome)} · ${esc(c.marca)} ${esc(c.modelo)}${c.placa?' · '+esc(c.placa):''}</option>`).join(''); }
function mecOpts(val){ return DB.mecanicos.map(m=>`<option value="${esc(m)}" ${m===val?'selected':''}>${esc(m)}</option>`).join(''); }

function formHtml(tipo,d){
  d=d||{};
  switch(tipo){
    case 'cliente': return `
      <div class="full"><label>Nome do cliente</label><input name="nome" required value="${esc(d.nome)}"></div>
      <div><label>Telefone</label><input name="telefone" value="${esc(d.telefone)}"></div>
      <div></div>
      <div><label>Marca do veículo</label><input name="marca" value="${esc(d.marca)}"></div>
      <div><label>Modelo</label><input name="modelo" value="${esc(d.modelo)}"></div>
      <div><label>Placa</label><input name="placa" value="${esc(d.placa)}" placeholder="ABC-1D23"></div>`;
    case 'ordem': return `
      <div class="full"><label>Cliente / Veículo</label><select name="clienteId">${cliOpts(d.clienteId)}</select></div>
      <div class="full"><label>Descrição do serviço</label><textarea name="descricao" required>${esc(d.descricao)}</textarea></div>
      <div><label>Mecânico</label><select name="mecanico">${mecOpts(d.mecanico)}</select></div>
      <div><label>Data de entrada</label><input type="date" name="entrada" value="${esc(d.entrada)||'2025-09-24'}"></div>
      <div><label>Status</label><select name="status">${Object.keys(STATUS).map(k=>`<option value="${k}" ${d.status===k?'selected':''}>${STATUS[k].t}</option>`).join('')}</select></div>
      <div><label>Valor (R$)</label><input type="number" step="0.01" name="valor" value="${esc(d.valor)}"></div>
      <div><label>Situação do pagamento</label><select name="pago"><option value="false" ${!d.pago?'selected':''}>Pendente</option><option value="true" ${d.pago?'selected':''}>Pago</option></select></div>
      <div><label>Forma de pagamento</label><select name="formaPagamento">${getPagamentos().map(p=>`<option value="${esc(p)}" ${d.formaPagamento===p?'selected':''}>${esc(p)}</option>`).join('')}</select></div>`;
    case 'agendamento': return `
      <div class="full"><label>Cliente / Veículo</label><select name="clienteId">${cliOpts(d.clienteId)}</select></div>
      <div class="full"><label>Serviço</label><input name="servico" required value="${esc(d.servico)}"></div>
      <div><label>Data</label><input type="date" name="data" required value="${esc(d.data)||'2025-09-24'}"></div>
      <div><label>Hora</label><input type="time" name="hora" required value="${esc(d.hora)||'09:00'}"></div>
      <div class="full"><label>Mecânico</label><select name="mecanico">${mecOpts(d.mecanico)}</select></div>`;
    case 'peca': return `
      <div class="full"><label>Nome da peça</label><input name="nome" required value="${esc(d.nome)}"></div>
      <div><label>Categoria</label><select name="categoria">${(function(){const cats=DB.config.categorias.slice();if(d.categoria&&!cats.includes(d.categoria))cats.unshift(d.categoria);return cats.map(c=>`<option value="${esc(c)}" ${d.categoria===c?'selected':''}>${esc(c)}</option>`).join('');})()}</select></div>
      <div><label>Condição</label><select name="condicao"><option value="Nova" ${(d.condicao||'Nova')==='Nova'?'selected':''}>Nova</option><option value="Seminova" ${d.condicao==='Seminova'?'selected':''}>Seminova</option><option value="Usada" ${d.condicao==='Usada'?'selected':''}>Usada</option></select></div>
      <div><label>Preço (R$)</label><input type="number" step="0.01" name="preco" value="${esc(d.preco)}"></div>
      <div><label>Quantidade</label><input type="number" name="qtd" value="${esc(d.qtd)}"></div>
      <div><label>Estoque mínimo</label><input type="number" name="minimo" value="${esc(d.minimo)}"></div>
      <div class="full"><label>Foto da peça</label>
        <div style="display:flex;gap:12px;align-items:center">
          <div id="pecaFotoPrev" style="width:84px;height:84px;border-radius:10px;background:#e5e7eb;display:flex;align-items:center;justify-content:center;overflow:hidden;font-size:28px;flex-shrink:0">${d.foto?`<img src="${d.foto}" style="width:100%;height:100%;object-fit:cover">`:'📷'}</div>
          <div style="display:flex;flex-direction:column;gap:6px">
            <label class="btn-edit" style="cursor:pointer">📷 Escolher foto<input type="file" id="pecaFotoInput" accept="image/*" hidden></label>
            <button type="button" class="icon-btn danger" id="pecaFotoRm" ${d.foto?'':'hidden'}>🗑️ Remover foto</button>
          </div>
        </div>
        <input type="hidden" name="foto" id="pecaFotoVal" value="${esc(d.foto)}">
      </div>`;
  }
  return '';
}

const COLLECTION={cliente:'clientes',ordem:'ordens',agendamento:'agenda',peca:'estoque'};
const LABELS={cliente:'Cliente',ordem:'Ordem de Serviço',agendamento:'Agendamento',peca:'Peça'};
let editing={tipo:null,id:null};

function openModal(tipo,id){
  editing={tipo,id:id?Number(id):null};
  const coll=DB[COLLECTION[tipo]];
  const d=id?coll.find(x=>x.id===Number(id)):{};
  document.getElementById('modalTitle').textContent=(id?'Editar ':'Novo ')+LABELS[tipo];
  document.getElementById('modalForm').innerHTML=formHtml(tipo,d);
  if(tipo==='peca') bindPecaFoto();
  document.getElementById('modalBackdrop').hidden=false;
}
function bindPecaFoto(){
  const inp=document.getElementById('pecaFotoInput');
  const val=document.getElementById('pecaFotoVal');
  const prev=document.getElementById('pecaFotoPrev');
  const rm=document.getElementById('pecaFotoRm');
  if(inp) inp.addEventListener('change',e=>{
    const f=e.target.files[0]; if(!f) return;
    const r=new FileReader();
    r.onload=ev=>{const img=new Image();img.onload=()=>{
      const cv=document.createElement('canvas');const max=600;let w=img.width,h=img.height;
      if(w>h){if(w>max){h=Math.round(h*max/w);w=max;}}else{if(h>max){w=Math.round(w*max/h);h=max;}}
      cv.width=w;cv.height=h;cv.getContext('2d').drawImage(img,0,0,w,h);
      const data=cv.toDataURL('image/jpeg',0.8);
      val.value=data; prev.innerHTML='<img src="'+data+'" style="width:100%;height:100%;object-fit:cover">'; if(rm) rm.hidden=false;
    };img.src=ev.target.result;};
    r.readAsDataURL(f);
  });
  if(rm) rm.addEventListener('click',()=>{ val.value=''; prev.innerHTML='📷'; rm.hidden=true; });
}
function closeModal(){ document.getElementById('modalBackdrop').hidden=true; editing={tipo:null,id:null}; }

function submitModal(e){
  e.preventDefault();
  const{tipo,id}=editing; if(!tipo) return;
  const fd=new FormData(e.target); const obj={};
  fd.forEach((v,k)=>{obj[k]=v;});
  ['clienteId','valor','qtd','minimo','preco'].forEach(k=>{if(obj[k]!==undefined&&obj[k]!=='')obj[k]=Number(obj[k]);});
  if('pago' in obj) obj.pago=obj.pago==='true';
  const coll=DB[COLLECTION[tipo]];
  if(id){ const i=coll.findIndex(x=>x.id===id); coll[i]={...coll[i],...obj}; toast(LABELS[tipo]+' atualizado'); }
  else{ obj.id=nextId(coll); coll.push(obj); toast(LABELS[tipo]+' adicionado'); }
  save(); closeModal(); render();
}

function delItem(tipo,id){
  id=Number(id);
  if(!confirm('Deseja realmente excluir este registro?')) return;
  const coll=DB[COLLECTION[tipo]];
  const i=coll.findIndex(x=>x.id===id);
  if(i>-1){ coll.splice(i,1); save(); toast(LABELS[tipo]+' excluído'); render(); }
}

// ===== EVENTOS =====
function bindViewEvents(){
  document.querySelectorAll('[data-add]').forEach(b=>b.addEventListener('click',()=>openModal(b.dataset.add)));
  document.querySelectorAll('[data-edit]').forEach(b=>b.addEventListener('click',()=>openModal(b.dataset.edit,b.dataset.id)));
  document.querySelectorAll('[data-del]').forEach(b=>b.addEventListener('click',()=>delItem(b.dataset.del,b.dataset.id)));
  document.querySelectorAll('[data-goto]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.goto)));
  const fs=document.getElementById('formSite');
  if(fs) fs.addEventListener('submit',e=>{e.preventDefault();const fd=new FormData(e.target);DB.config.nomeSite=(fd.get('nomeSite')||'Oficina').trim();DB.config.subtitulo=(fd.get('subtitulo')||'').trim();DB.config.telefone=(fd.get('telefone')||'').trim();DB.config.endereco=(fd.get('endereco')||'').trim();DB.config.cnpj=(fd.get('cnpj')||'').trim();DB.config.email=(fd.get('email')||'').trim();DB.config.abertura=(fd.get('abertura')||'').trim();DB.config.fechamento=(fd.get('fechamento')||'').trim();DB.config.dias=(fd.get('dias')||'').trim();DB.config.cor=fd.get('cor')||'#2563eb';save();applyBrand();applyTheme();toast('Dados do site salvos');});
  const fperf=document.getElementById('formPerfil');
  if(fperf) fperf.addEventListener('submit',e=>{e.preventDefault();const nome=(new FormData(e.target).get('nome')||'').trim();if(!nome)return;currentUser.nome=nome;const u=DB.usuarios.find(x=>x.id===currentUser.id);if(u)u.nome=nome;save();updateUserChip();toast('Perfil salvo');render();});
  const fin=document.getElementById('fotoInput');
  if(fin) fin.addEventListener('change',e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=ev=>{const img=new Image();img.onload=()=>{const cv=document.createElement('canvas');const max=200;let w=img.width,h=img.height;if(w>h){if(w>max){h=Math.round(h*max/w);w=max;}}else{if(h>max){w=Math.round(w*max/h);h=max;}}cv.width=w;cv.height=h;cv.getContext('2d').drawImage(img,0,0,w,h);const data=cv.toDataURL('image/jpeg',0.85);currentUser.foto=data;const u=DB.usuarios.find(x=>x.id===currentUser.id);if(u)u.foto=data;save();updateUserChip();toast('Foto atualizada');render();};img.src=ev.target.result;};r.readAsDataURL(f);});
  const rmf=document.getElementById('rmFoto');
  if(rmf) rmf.addEventListener('click',()=>{delete currentUser.foto;const u=DB.usuarios.find(x=>x.id===currentUser.id);if(u)delete u.foto;save();updateUserChip();toast('Foto removida');render();});
  const fm=document.getElementById('formMec');
  if(fm) fm.addEventListener('submit',e=>{e.preventDefault();const nome=(new FormData(e.target).get('nome')||'').trim();if(!nome)return;if(DB.mecanicos.includes(nome)){toast('Esse mecânico já existe');return;}DB.mecanicos.push(nome);save();toast('Mecânico adicionado');render();});
  document.querySelectorAll('[data-rmmec]').forEach(b=>b.addEventListener('click',()=>{const nome=b.dataset.rmmec;if(confirm('Remover o mecânico "'+nome+'"?')){DB.mecanicos=DB.mecanicos.filter(m=>m!==nome);save();toast('Mecânico removido');render();}}));
  const fp=document.getElementById('formPag');
  if(fp) fp.addEventListener('submit',e=>{e.preventDefault();const nome=(new FormData(e.target).get('nome')||'').trim();if(!nome)return;if(DB.config.pagamentos.includes(nome)){toast('Essa forma já existe');return;}DB.config.pagamentos.push(nome);save();toast('Forma de pagamento adicionada');render();});
  document.querySelectorAll('[data-rmpag]').forEach(b=>b.addEventListener('click',()=>{const nome=b.dataset.rmpag;if(confirm('Remover a forma "'+nome+'"?')){DB.config.pagamentos=DB.config.pagamentos.filter(p=>p!==nome);save();toast('Forma removida');render();}}));
  const fu=document.getElementById('formUser');
  if(fu) fu.addEventListener('submit',e=>{e.preventDefault();const fd=new FormData(e.target);const nome=(fd.get('nome')||'').trim();const login=(fd.get('login')||'').trim();const senha=fd.get('senha')||'';const perfil=fd.get('perfil')||'Atendente';if(!nome||!login||!senha)return;if(DB.usuarios.some(u=>(u.login||'').toLowerCase()===login.toLowerCase())){toast('Esse login já existe');return;}DB.usuarios.push({id:nextId(DB.usuarios),nome,login,perfil,senhaPlain:senha});save();toast('Usuário adicionado');render();});
  document.querySelectorAll('[data-rmuser]').forEach(b=>b.addEventListener('click',()=>{const id=Number(b.dataset.rmuser);if(DB.usuarios.length<=1){toast('Deve existir ao menos um usuário');return;}if(currentUser&&currentUser.id===id){toast('Não é possível remover o usuário logado');return;}if(confirm('Remover este usuário?')){DB.usuarios=DB.usuarios.filter(u=>u.id!==id);save();toast('Usuário removido');render();}}));
  document.querySelectorAll('[data-pwuser]').forEach(b=>b.addEventListener('click',()=>{const id=Number(b.dataset.pwuser);const u=DB.usuarios.find(x=>x.id===id);if(!u)return;const nova=prompt('Nova senha para "'+u.nome+'":');if(nova==null||nova==='')return;u.senhaPlain=nova;save();toast('Senha atualizada');}));
  const fcat=document.getElementById('formCat');
  if(fcat) fcat.addEventListener('submit',e=>{e.preventDefault();const nome=(new FormData(e.target).get('nome')||'').trim();if(!nome)return;if(DB.config.categorias.includes(nome)){toast('Essa categoria já existe');return;}DB.config.categorias.push(nome);save();toast('Categoria adicionada');render();});
  document.querySelectorAll('[data-rmcat]').forEach(b=>b.addEventListener('click',()=>{const nome=b.dataset.rmcat;if(confirm('Remover a categoria "'+nome+'"?')){DB.config.categorias=DB.config.categorias.filter(c=>c!==nome);save();toast('Categoria removida');render();}}));
  const fa11y=document.getElementById('formA11yUI');
  if(fa11y) fa11y.addEventListener('submit',e=>{e.preventDefault();const fd=new FormData(e.target);DB.config.a11yUI={escala:fd.get('escala')==='on',escuro:fd.get('escuro')==='on',contraste:fd.get('contraste')==='on',animacoes:fd.get('animacoes')==='on',teclado:fd.get('teclado')==='on',botao:fd.get('botao')||'topbar'};save();applyA11yUI();toast('Opções de acessibilidade salvas');});
  const fperms=document.getElementById('formPerms');
  if(fperms) fperms.addEventListener('submit',e=>{e.preventDefault();const fd=new FormData(e.target);DB.config.permissoes={'Atendente':fd.getAll('Atendente'),'Mecânico':fd.getAll('Mecânico')};save();applyPermissions();toast('Acessos por perfil salvos');});
  const bkp=document.getElementById('btnBackup');
  if(bkp) bkp.addEventListener('click',()=>{const blob=new Blob([JSON.stringify(DB,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');const hoje=new Date().toISOString().slice(0,10);a.href=url;a.download='oficina-backup-'+hoje+'.json';document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);toast('Cópia de segurança baixada');});
  const imp=document.getElementById('importInput');
  if(imp) imp.addEventListener('change',e=>{const f=e.target.files[0];if(!f)return;if(!confirm('Restaurar vai substituir TODOS os dados atuais. Deseja continuar?')){e.target.value='';return;}const r=new FileReader();r.onload=ev=>{try{const dados=JSON.parse(ev.target.result);if(!dados||typeof dados!=='object'||!Array.isArray(dados.usuarios)){toast('Arquivo inválido');return;}DB=normalize(dados);save();toast('Dados restaurados');render();}catch(err){toast('Não foi possível ler o arquivo');}};r.readAsText(f);});
}

// ===== AUTENTICAÇÃO =====
function showLogin(){
  document.getElementById('app').hidden=true;
  document.getElementById('loginScreen').hidden=false;
  const u=document.getElementById('loginUser'), p=document.getElementById('loginPass'), er=document.getElementById('loginErr');
  u.value=''; p.value=''; er.hidden=true;
  setTimeout(()=>u.focus(),60);
}
function updateUserChip(){
  if(!currentUser) return;
  document.getElementById('userName').textContent=currentUser.nome;
  document.getElementById('userRole').textContent=currentUser.perfil;
  const av=document.getElementById('userAvatar');
  const parts=String(currentUser.nome).trim().split(/\s+/);
  const ini=((parts[0]||'')[0]||'')+((parts[1]||'')[0]||'');
  if(currentUser.foto){
    av.textContent='';
    av.style.backgroundImage='url('+currentUser.foto+')';
    av.style.backgroundSize='cover';
    av.style.backgroundPosition='center';
  }else{
    av.style.backgroundImage='';
    av.textContent=(ini||(parts[0]||'U')[0]).toUpperCase();
  }
}
function showApp(){
  document.getElementById('loginScreen').hidden=true;
  document.getElementById('app').hidden=false;
  updateUserChip();
  applyBrand();
  applyTheme();
  applyPermissions();
  navigate('dashboard');
}
async function doLogin(e){
  e.preventDefault();
  const login=document.getElementById('loginUser').value.trim().toLowerCase();
  const senha=document.getElementById('loginPass').value;
  const er=document.getElementById('loginErr');
  try{
    const r=await fetch(API+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({login,senha})});
    if(!r.ok){ er.textContent='Usuário ou senha incorretos.'; er.hidden=false; return; }
    const j=await r.json();
    token=j.token; localStorage.setItem(TOKEN_KEY,token); localStorage.setItem(UID_KEY,String(j.userId));
    DB=await fetchDB();
    currentUser=(DB.usuarios.find(x=>x.id===j.userId))||DB.usuarios[0];
    showApp();
  }catch(err){ er.textContent='Não foi possível conectar ao servidor.'; er.hidden=false; }
}
function logout(){ currentUser=null; token=null; DB=null; localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(UID_KEY); showLogin(); }

function init(){
  loadA11y();
  applyA11y();
  bindA11y();
  document.querySelectorAll('.menu-item').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.view)));
  document.getElementById('burger').addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));
  document.getElementById('globalSearch').addEventListener('input',e=>{searchTerm=e.target.value.trim();render();});
  document.getElementById('modalForm').addEventListener('submit',submitModal);
  document.getElementById('modalClose').addEventListener('click',closeModal);
  document.getElementById('modalCancel').addEventListener('click',closeModal);
  document.getElementById('modalBackdrop').addEventListener('click',e=>{if(e.target.id==='modalBackdrop')closeModal();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});
  document.getElementById('btnReset').addEventListener('click',()=>{
    if(confirm('Restaurar os dados de demonstração? As alterações e usuários serão perdidos.')){
      fetch(API+'/api/reset',{method:'POST',headers:authHeaders()}).then(r=>{ if(!r.ok) throw 0; toast('Dados restaurados'); logout(); }).catch(()=>toast('Não foi possível restaurar'));
    }
  });
  document.getElementById('loginForm').addEventListener('submit',doLogin);
  document.getElementById('btnLogout').addEventListener('click',logout);
  // restaura sessão se o token ainda estiver salvo
  const st=localStorage.getItem(TOKEN_KEY);
  const uid=Number(localStorage.getItem(UID_KEY));
  if(st){
    token=st;
    fetchDB().then(d=>{ if(!d){ logout(); return; } DB=d; currentUser=(DB.usuarios.find(x=>x.id===uid))||DB.usuarios[0]; showApp(); }).catch(()=>logout());
  } else { showLogin(); }
}
document.addEventListener('DOMContentLoaded',init);
